TAUSEEF SALEEM — GRAPHIC DESIGN PORTFOLIO

This is a responsive, static portfolio website built with HTML, CSS and vanilla JavaScript.

PREVIEW
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Keep the assets folder beside index.html; the page loads all project images from it.

PUBLISHING
You can publish this folder using Netlify Drop, GitHub Pages, or any static website host. Upload the complete folder (or its contents) so index.html and the assets folder remain together.

CUSTOMIZATION
- Edit your name, biography, service descriptions and project captions in index.html.
- Replace assets/tauseef-portrait.jpg with a preferred portrait if desired.
- Replace or add portfolio images in assets and update the corresponding project cards in index.html.
- WhatsApp buttons currently point to +91 88071 06473.

NOTES
- The site uses Google Fonts; a network connection is required for those fonts. It falls back to system fonts if unavailable.
- No email address or social profiles were supplied, so none have been invented or displayed.
- The supplied portrait is used as a darkened, blended crop; it has not been precisely background-removed.
- Only the supplied sample designs are included. No unverified client counts, ratings, testimonials or project totals are claimed.
