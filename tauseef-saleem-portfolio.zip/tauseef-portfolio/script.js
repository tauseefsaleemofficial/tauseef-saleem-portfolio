const menuButton=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav');
menuButton.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false');}));

const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target);}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));

const filters=document.querySelectorAll('.filter');
const projects=[...document.querySelectorAll('.project-card')];
filters.forEach(button=>button.addEventListener('click',()=>{filters.forEach(f=>f.classList.remove('active'));button.classList.add('active');const filter=button.dataset.filter;projects.forEach(card=>card.classList.toggle('hide',filter!=='all'&&card.dataset.category!==filter));}));

const lightbox=document.querySelector('.lightbox'), lightboxImage=lightbox.querySelector('img'), captionTitle=lightbox.querySelector('.lightbox-caption b'), captionText=lightbox.querySelector('.lightbox-caption span');
let currentIndex=0;
function openProject(index){currentIndex=(index+projects.length)%projects.length;const card=projects[currentIndex];lightboxImage.src=card.dataset.image;lightboxImage.alt=card.dataset.title;captionTitle.textContent=card.dataset.title;captionText.textContent=card.dataset.description;lightbox.classList.add('open');lightbox.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
function closeProject(){lightbox.classList.remove('open');lightbox.setAttribute('aria-hidden','true');document.body.style.overflow='';}
projects.forEach((card,index)=>card.addEventListener('click',()=>openProject(index)));
lightbox.querySelector('.lightbox-close').addEventListener('click',closeProject);
lightbox.querySelector('.lightbox-prev').addEventListener('click',()=>openProject(currentIndex-1));
lightbox.querySelector('.lightbox-next').addEventListener('click',()=>openProject(currentIndex+1));
lightbox.addEventListener('click',e=>{if(e.target===lightbox)closeProject();});
document.addEventListener('keydown',e=>{if(!lightbox.classList.contains('open'))return;if(e.key==='Escape')closeProject();if(e.key==='ArrowRight')openProject(currentIndex+1);if(e.key==='ArrowLeft')openProject(currentIndex-1);});

const glow=document.querySelector('.cursor-glow');
if(window.matchMedia('(pointer:fine)').matches){window.addEventListener('pointermove',e=>{glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px';});}else{glow.style.display='none';}
document.querySelector('#year').textContent=new Date().getFullYear();
const sections=[...document.querySelectorAll('main section[id]')];
const navLinks=[...document.querySelectorAll('.nav a')];
const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){navLinks.forEach(link=>link.classList.toggle('active',link.getAttribute('href')==='#'+entry.target.id));}}),{rootMargin:'-35% 0px -55% 0px'});
sections.forEach(section=>sectionObserver.observe(section));
